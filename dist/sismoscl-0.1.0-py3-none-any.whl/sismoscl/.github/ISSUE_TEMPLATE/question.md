---
name: ❓ Question
about: Ask a question about this project 🎓
title: ''
labels: question
assignees:
---

## Checklist

<!-- Mark with an `x` all the checkboxes that apply (like `[x]`) -->

- [ ] I've searched the project's [`issues`](https://github.com/fraediaz/sismoscl/issues?q=is%3Aissue).

## ❓ Question

<!-- What is your question -->

How can I [...]?

Is it possible to [...]?

## 📎 Additional context

<!-- Add any other context or screenshots about the feature request here. -->
